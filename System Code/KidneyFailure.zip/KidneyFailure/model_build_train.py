from flask import Flask, render_template,request,jsonify,redirect,url_for
# from jinja2 import escape
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.style as style
style.use('classic')
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.impute import KNNImputer
from sklearn.metrics import accuracy_score
import warnings
# from sklearn.externals import joblib
import joblib
warnings.filterwarnings(action='ignore')
import io
import base64

app = Flask(__name__)

#-------------------------------Logistic Regression Model build start----------------------------------------------------------


def ckd_logistic(data):
    data = pd.DataFrame(data)
    
    # print("before {}".format(len(data.columns)))

    # 26 feature names here
    
    feature_names = ['id','Age (yrs)','Blood Pressure (mm/Hg)','Specific Gravity','Albumin (g/dL)','Sugar','Red Blood Cells',
                'Pus Cells','Pus Cell Clumps','Bacteria','Blood Glucose Random (mgs/dL)','Blood Urea (mgs/dL)',
                'Serum Creatinine (mgs/dL)','Sodium (mEq/L)','Potassium (mEq/L)','Hemoglobin (gms)','Packed Cell Volume',
                'White Blood Cells (cells/cmm)','Red Blood Cells (millions/cmm)','Hypertension','Diabetes Mellitus',
                'Coronary Artery Disease','Appetite','Pedal Edema','Anemia','Chronic Kidney Disease Label']
    
    # 1 target variable
    target = 'Chronic Kidney Disease Label' 
    data.columns = feature_names

    y_target = data.iloc[:, -1]                       # only target
    y_target = y_target.replace({'ckd': 1, 'notckd': 0}).astype(float)

    categorical_columns = ['id','Red Blood Cells','Pus Cells','Pus Cell Clumps','Bacteria','Hypertension','Diabetes Mellitus',
                 'Coronary Artery Disease','Appetite','Pedal Edema','Anemia','Chronic Kidney Disease Label']
    
    data     = data.drop(categorical_columns,axis=1)  # drop ID + categorical columns but contains other numerical features + target



    # Convert any remaining missing values or special characters to NaN
    data_clean = data.replace(['?','\t'], pd.NA)    # only numeric features + target here   i.e. X + Y?
   
    
    # Convert the numeric one hot encoded columns to float data type
    numeric_columns = data_clean.select_dtypes(include='number').columns      # only numeric feature i.e. X
    print(numeric_columns)
    data_clean[numeric_columns] = data_clean[numeric_columns].astype(float)   # only numeric feature i.e. X
    

    # # Replace special characters and missing values with NaN
    data_clean = data_clean.replace(['?', '\t?'], pd.NA)

    # Fill missing values with a suitable value (e.g., 0)
    data_clean = data_clean.fillna(0)                                    # only numeric feature i.e. X 
    print(data_clean)


    # Split the data into training and testing sets
    X = data_clean               # numeric features
    print(X.head(5))
    Y = y_target                 # target feature
    print(Y.unique())

    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
    print(Y_train.unique())

    # Train a logistic regression model
    model = LogisticRegression()
    model.fit(X_train, Y_train)


    classify = model.predict(X_test)

    # test the model accuracy
    accuracy_A = accuracy_score(Y_test,classify)

    return model

data  = pd.read_csv("kidney_disease.csv")
model = ckd_logistic(data)
# Save the trained model to a file
joblib.dump(model, 'logistic_regression_model.pkl')