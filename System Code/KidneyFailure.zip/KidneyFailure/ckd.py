from flask import Flask, render_template,request,jsonify,redirect,url_for
# from jinja2 import escape
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.style as style
style.use('classic')
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.impute import KNNImputer
from sklearn.metrics import accuracy_score
import warnings
import joblib
warnings.filterwarnings(action='ignore')
import io
import base64

# create Flask App for your web application

app = Flask(__name__)


#-------------------------------------------------------------------------------------------

# home page url
@app.route("/index.html")
def home():
       
        return render_template("index.html")

# about url
@app.route("/about.html")
def about():
        
        return render_template("about.html")

# ckd url
@app.route("/ckd.html")
def ckd():
        
        return render_template("ckd.html")


@app.route("/ckdstatus.html")
def ckdstatus():
        
        return render_template("ckdstatus.html")

#-------------------------CKD Prediction results--------------------------------------------------------
@app.route("/ckdstatus.html",methods=["POST"])

#-------getting user input data for prediction----------------------------------------------------------

def getvalue():
    if request.method == "POST":
       # Get the form data
        id  = request.form['id']
        age = request.form['age']
        bloodpressure = request.form['bloodpressure']
        specificgravity = request.form['specificgravity']
        albumin = request.form['albumin']
        sugar = request.form['sugar']
        # rbc = request.form['rbc']
        # pc = request.form['pc']
        # pcc = request.form['pcc']
        # bacteria = request.form['bacteria']
        bloodglucose = request.form['bloodglucose']
        bloodurea = request.form['bloodurea']
        serumcreatinine = request.form['serumcreatinine']
        sodium = request.form['sodium']
        potassium = request.form['potassium']
        hemoglobin = request.form['hemoglobin']
        pcv = request.form['pcv']
        wbccount = request.form['wbccount']
        rbccount = request.form['rbccount']
        # hypertension = request.form['hypertension']
        # diabetesmellitus = request.form['diabetesmellitus']
        # coronaryheart = request.form['coronaryheart']
        # appetite = request.form['appetite']
        # pedaledema = request.form['pedaledema']
        # anaemia = request.form['anaemia']


        # print("id:{}".format(id))


        # Create a DataFrame with the form data
        data = pd.DataFrame({
            # 'id':[id],
            'Age (yrs)': [age],
            'Blood Pressure (mm/Hg)': [bloodpressure],
            'Specific Gravity': [specificgravity],
            'Albumin (g/dL)': [albumin],
            'Sugar': [sugar],
            # 'rbc': [rbc],
            # 'pc': [pc],
            # 'pcc': [pcc],
            # 'bacteria': [bacteria],
            'Blood Glucose Random (mgs/dL)': [bloodglucose],
            'Blood Urea (mgs/dL)': [bloodurea],
            'Serum Creatinine (mgs/dL)': [serumcreatinine],
            'Sodium (mEq/L)': [sodium],
            'Potassium (mEq/L)': [potassium],
            'Hemoglobin (gms)': [hemoglobin],
            'Packed Cell Volume': [pcv],
            'White Blood Cells (cells/cmm)': [wbccount],
            'Red Blood Cells (millions/cmm)': [rbccount],
            # 'hypertension': [hypertension],
            # 'diabetesmellitus': [diabetesmellitus],
            # 'coronaryheart': [coronaryheart],
            # 'appetite': [appetite],
            # 'pedaledema': [pedaledema],
            # 'anaemia': [anaemia]
        })

        # Load the saved model from file
        model = joblib.load('logistic_regression_model.pkl')
        classify = model.predict(data.astype(float))
        if classify == 1.0:
              classify = 'Patient has CKD'
        else:
              classify = "Patient doesn't have CKD"
        
        print(classify)


    return render_template('ckdstatus.html',classify=classify)

# --------------------------------------------CKD Prediction End---------------------------------------------------   

#-------------------------------------------CKD Data Analysis and plotting ----------------------------------------
@app.route("/ckdanalysis.html")
# def ckdanalysis():
        
# return render_template("ckdanalysis.html",value=sum(),content=analysis())
       

def analysis():
    data = pd.read_csv("kidney_disease.csv")

    feature_names=['id','Age (yrs)','Blood Pressure (mm/Hg)','Specific Gravity','Albumin (g/dL)','Sugar','Red Blood Cells',
               'Pus Cells','Pus Cell Clumps','Bacteria','Blood Glucose Random (mgs/dL)','Blood Urea (mgs/dL)',
               'Serum Creatinine (mgs/dL)','Sodium (mEq/L)','Potassium (mEq/L)','Hemoglobin (gms)','Packed Cell Volume',
               'White Blood Cells (cells/cmm)','Red Blood Cells (millions/cmm)','Hypertension','Diabetes Mellitus',
               'Coronary Artery Disease','Appetite','Pedal Edema','Anemia','Chronic Kidney Disease Label']
    
    data.columns=feature_names

    # drop 'id' column
    data.drop('id',axis=1,inplace=True)
    # Perform one-hot encoding on categorical columns
    categorical_columns = ['Red Blood Cells','Pus Cells','Pus Cell Clumps','Bacteria','Hypertension','Diabetes Mellitus',
                'Coronary Artery Disease','Appetite','Pedal Edema','Anemia','Chronic Kidney Disease Label']

    encoder = OneHotEncoder(sparse=False, drop='first')
    encoded_data = pd.DataFrame(encoder.fit_transform(data[categorical_columns]))
    encoded_data.columns = encoder.get_feature_names_out(categorical_columns)

    # Concatenate the encoded data with the remaining columns
    data_cleaned = pd.concat([data.drop(categorical_columns, axis=1), encoded_data], axis=1)

    # Convert any remaining missing values or special characters to NaN
    data_cleaned = data_cleaned.replace('?', pd.NA)

    # Convert the numeric columns to float data type
    numeric_columns = data_cleaned.select_dtypes(include='number').columns
    data_cleaned[numeric_columns] = data_cleaned[numeric_columns].astype(float)

    # Identify numeric columns
    numeric_columns = data_cleaned.select_dtypes(include='number').columns

    # Determine the number of rows and columns for subplots
    n_features = len(numeric_columns)
    n_rows = (n_features + 1) // 2
    n_cols = min(2, n_features)

    # Adjust the figure size
    fig_width = 20
    fig_height = 5 * n_rows  # Increase the figure height to create more vertical spacing
    fig, axes = plt.subplots(nrows=n_rows, ncols=n_cols, figsize=(fig_width, fig_height))

    # Plot probability distributions of missing values
    for index, column in enumerate(numeric_columns):
        i, j = divmod(index, n_cols)
        ax = axes[i, j] if n_rows > 1 else axes[j]
        
        miss_perc = (1 - data_cleaned[column].count() / data_cleaned.shape[0]) * 100
        collabel = f"{column}\n({miss_perc:.2f}% is missing)".format(miss_perc)
        
        sns.histplot(data=data_cleaned, x=column, ax=ax, kde=True, label=collabel)
        ax.set_xlabel(None)
        ax.legend(fontsize=12)
        ax.set_ylabel("Probability Density", fontsize=12)

    # Create a BytesIO object to save the plot
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convert the plot to base64 and pass it to the template
    plot_prob = base64.b64encode(buffer.getvalue()).decode('utf-8')  
    
  
    
#--------------------------correlation coefficient-------------------------------------

    # Caclulate the correlation matrix
    correlation_matrix = data_cleaned.corr()

    # Create a BytesIO object to save the plot
    buffer = io.BytesIO()

    # Plot the correlation matrix as a heatmap
    plt.figure(figsize=(16, 13))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5,annot_kws={"size": 8})
    plt.title("Pearson Correlation Coefficient")
    plt.xticks(rotation=70)
    plt.yticks(rotation=0)
    plt.tight_layout()

    # Save the plot to the BytesIO buffer
    plt.savefig(buffer, format='png')
    buffer.seek(0)

    # Convert the plot to base64
    plot_corr = base64.b64encode(buffer.getvalue()).decode('utf-8')

    return render_template("ckdanalysis.html", content1= plot_prob,content2 = plot_corr)

#------------------------------- CKD Data Analysis and plotting end ----------------------------------------

#------------------------------- CKD dataset ----------------------------------------------------------
@app.route("/ckddataset.html")
def ckddataset():
        
        return render_template("ckddataset.html")

#------------------------------------------------------------------------------------------------------

@app.route('/ckdanalysis.html')
def ckd_analysis():
    return render_template('ckdanalysis.html')


@app.route('/chatbot.html')
def chatbot():
     return render_template('chatbot.html')




# --------------------code execution starts here-----------------------
if __name__ =='__main__':
    app.run(debug=True,port=5002)
